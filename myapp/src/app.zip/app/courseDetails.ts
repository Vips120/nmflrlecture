export class CourseDetails {
    courses():string[]{
       return ["Angular", "javascript", "typescript", "nodejs"];
    }
}